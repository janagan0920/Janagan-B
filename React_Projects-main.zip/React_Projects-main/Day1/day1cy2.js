import React from "react";

const Firstd1cy2 = () => {
    let myarray=['North','']
}