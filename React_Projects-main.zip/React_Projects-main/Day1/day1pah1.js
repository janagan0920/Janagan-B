import React from 'react';

const Firstd1p1 = () => {
    return (
        <div>
            <p>This is Team Functional Component</p>
        </div>
    );
};

export default Firstd1p1;