

const App = () => {
  return (
    
      <div style={{backgroundColor:"Lightblue",fontSize:'10px',border:'1px solid blue',borderRadius:'5px'}}>
        <h1 style={{color: "green"}}>Inline Style in JSX Example.</h1>
        <p style={{color: "darkblue",fontSize:'16px'}}>This is a paragraph with inline styles applied.</p>
      </div>
  );
}

export default App;