function Form(){
    return(
        <>
        <h1>Feed Back Form</h1>
        <div>
            <p>Name : </p>
            <input type="text"></input>
            <p>Email : </p>
            <input type=""email></input>
            <p>Message</p>
            <input type="message"></input>
        </div>
        </>
    )
}
export default Form