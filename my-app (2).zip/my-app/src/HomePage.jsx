import React from 'react';
import './HomePage.css';
import { useNavigate } from 'react-router-dom';

const HomePage = () => {
    const navigate = useNavigate();

    const handleFindDoctorClick = () => {
        navigate('/findadoctor');
    };

    const handleContactClick = () => {
        navigate('/contact');
    };

    const handleBillingClick = () => {
        navigate('/billing');
    };

    const handleDepartmentsClick = () => {
        navigate('/departments'); // Navigate to Departments page
    };

    const handleLoginClick = () => {
        navigate('/'); // Navigate to Login page
    };

    const handleBookAppointmentClick = () => {
        navigate('/bookappointment'); // Navigate to Booking Appointment page
    };

    return (
        <div className="homepage">
            <header className="header">
                <div className="logo">MAYO CLINIC</div>
                <nav className="navbar">
                    <ul>
                        <li>Care at Mayo Clinic</li>
                        <li onClick={handleFindDoctorClick}>Find a Doctor</li>
                        <li onClick={handleDepartmentsClick}>Departments & Centers</li>
                        <li onClick={handleBillingClick}>Billing & Insurance</li>
                        <li onClick={handleContactClick}>Contact Us</li>
                    </ul>
                </nav>
                <div className="user-actions">
                    <button className="appointment-button" onClick={handleBookAppointmentClick}>Book Appointment</button>
                    <button className="login-button" onClick={handleLoginClick}>Log in</button>
                    <button className="search-button">🔍</button>
                </div>
            </header>
            <main className="main-content">
                <div className="video-section">
                    <video autoPlay loop muted playsInline className="background-video">
                        <source src="https://cdn.pixabay.com/video/2019/09/19/27019-361107952_large.mp4" type="video/webm" />
                        Your browser does not support the video tag.
                    </video>
                    <div className="overlay-text">
                        <h1>Transforming your care</h1>
                        <div className="actions">
                            <button className="learn-more">Learn how we drive innovation</button>
                            <button className="request-appointment">Request appointment</button>
                        </div>
                    </div>
                </div>
            </main>
            <footer className="feedback">
                <button>Feedback</button>
            </footer>
        </div>
    );
};

export default HomePage;
