import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import './Login.css';

function Login() {
  const [loginData, setLoginData] = useState({
    email: '',
    password: ''
  });

  const navigate = useNavigate();

  const handleChange = (event) => {
    const { name, value } = event.target;
    setLoginData({
      ...loginData,
      [name]: value
    });
  };

  const handleSubmit = (event) => {
    event.preventDefault();

    // Fetch all users from the backend and check credentials
    axios.get('http://localhost:3001/user')
      .then(response => {
        const users = response.data;
        const user = users.find(user => user.email === loginData.email && user.password === loginData.password);
        if (user) {
          alert('Login successful!');
          navigate('/homepage');  // Navigate to homepage if login is successful
        } else {
          alert('Invalid email or password');
        }
      })
      .catch(error => {
        console.error('There was an error logging in!', error);
      });
  };

  return (
    <div className="login-page">
      {/* Video Background */}
      <video className="video-background" autoPlay muted loop>
        <source src="https://www.shutterstock.com/shutterstock/videos/1094139473/preview/stock-footage-future-hospitals-and-medical-technology.webm" type="video/webm" />
        Your browser does not support the video tag.
      </video>

      {/* Login Form */}
      <div className="login-container">
        <h2>Hospital - Login</h2>
        <form onSubmit={handleSubmit}>
          <div className="input-container">
            <label>Email:</label>
            <input type="email" name="email" value={loginData.email} onChange={handleChange} required />
          </div>
          <div className="input-container">
            <label>Password:</label>
            <input type="password" name="password" value={loginData.password} onChange={handleChange} required />
          </div>
          <button type="submit">Login</button>
        </form>
        <p>Don't have an account? <a href="/signup">Sign Up</a></p>
      </div>
    </div>
  );
}

export default Login;
