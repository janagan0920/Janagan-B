import React from 'react';
import './Billing.css';

const Billing = () => {
    return (
        <div className="billing-page">
            <div className="billing-header">
                <h1>Billing & Insurance</h1>
                <p>We provide transparent and convenient billing services to make your experience hassle-free.</p>
            </div>
            <div className="billing-content">
                <div className="billing-info">
                    <h2>Billing Information</h2>
                    <p><strong>Address:</strong> 4567 Medical Lane, Health City, TX 78901</p>
                    <p><strong>Phone:</strong> (987) 654-3210</p>
                    <p><strong>Email:</strong> mayocare@hospitalcare.com</p>
                    <h3>Payment Options</h3>
                    <p>We accept the following payment methods:</p>
                    <ul>
                        <li>Credit/Debit Cards (Visa, MasterCard, American Express)</li>
                        <li>Checks</li>
                        <li>Cash</li>
                        <li>Online Payment Portal</li>
                    </ul>
                </div>
                <div className="insurance-info">
                    <h2>Insurance Information</h2>
                    <p>We work with a wide range of insurance providers to ensure you get the coverage you need.</p>
                    <h3>Accepted Insurance Providers</h3>
                    <ul>
                        <li>Blue Cross Blue Shield</li>
                        <li>Aetna</li>
                        <li>Cigna</li>
                        <li>UnitedHealthcare</li>
                        <li>Medicare</li>
                        <li>Medicaid</li>
                    </ul>
                    <h3>Insurance Billing Process</h3>
                    <p>Our billing department will handle the submission of insurance claims on your behalf. If you have any questions, feel free to reach out to us.</p>
                </div>
                <div className="contact-billing">
                    <h2>Need Assistance?</h2>
                    <p>If you need help with billing or insurance, please contact our billing department.</p>
                    <button className="contact-button">Contact Billing Department</button>
                </div>
            </div>
        </div>
    );
};

export default Billing;
