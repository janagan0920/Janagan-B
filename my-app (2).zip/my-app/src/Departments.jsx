import React from 'react';
import './Departments.css';

const Departments = () => {
    const departments = [
        'Cardiology',
        'Dermatology',
        'Emergency Medicine',
        'Gastroenterology',
        'Neurology',
        'Oncology',
        'Pediatrics',
        'Radiology',
        'Orthopedics',
        'Psychiatry',
    ];

    return (
        <div className="departments-page">
            <h1>Departments & Centers</h1>
            <div className="departments-container">
                {departments.map((department, index) => (
                    <div key={index} className="department-box">
                        <h2>{department}</h2>
                        <p>Description of {department} department.</p>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default Departments;
