import React, { useState } from 'react';
import './BookingAppointment.css';

const BookingAppointment = () => {
    const [formData, setFormData] = useState({
        name: '',
        email: '',
        phone: '',
        date: '',
        department: '',
    });

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData({
            ...formData,
            [name]: value,
        });
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        console.log('Appointment booked:', formData);
        alert('Appointment Booked Successfully.');
        setFormData({ name: '', email: '', phone: '', date: '', department: '' });
    };

    return (
        <div className="booking-container">
            <img 
                className="background-image" 
                src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSp5-6Bed247l_lRM5oAs1n6HeRgNkmkk0oFg&s" 
                alt="Background"
            />
            <div className="form-overlay">
                <h2>Book Your Appointment</h2>
                <form className="booking-form" onSubmit={handleSubmit}>
                    <label>
                        Name:
                        <input
                            type="text"
                            name="name"
                            value={formData.name}
                            onChange={handleChange}
                            required
                        />
                    </label>
                    <label>
                        Email:
                        <input
                            type="email"
                            name="email"
                            value={formData.email}
                            onChange={handleChange}
                            required
                        />
                    </label>
                    <label>
                        Phone:
                        <input
                            type="tel"
                            name="phone"
                            value={formData.phone}
                            onChange={handleChange}
                            required
                        />
                    </label>
                    <label>
                        Appointment Date:
                        <input
                            type="date"
                            name="date"
                            value={formData.date}
                            onChange={handleChange}
                            required
                        />
                    </label>
                    <label>
                        Department:
                        <select
                            name="department"
                            value={formData.department}
                            onChange={handleChange}
                            required
                        >
                            <option value="">Select Department</option>
                            <option value="cardiology">Cardiology</option>
                            <option value="neurology">Neurology</option>
                            <option value="orthopedics">Orthopedics</option>
                            <option value="pediatrics">Pediatrics</option>
                        </select>
                    </label>
                    <button type="submit" className="submit-button">Book Appointment</button>
                </form>
            </div>
        </div>
    );
};

export default BookingAppointment;
