import React, { useState } from 'react';
import './Contact.css';

const Contact = () => {
    const [formData, setFormData] = useState({
        name: '',
        email: '',
        message: ''
    });

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData({
            ...formData,
            [name]: value
        });
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        alert('Message sent! We will get back to you shortly.');
        // Here, you can add form submission logic, such as sending data to a server
    };

    return (
        <div className="contact-page">
            <div className="video-background">
                <video autoPlay loop muted playsInline className="background-video">
                    <source src="https://www.shutterstock.com/shutterstock/videos/1106901987/preview/stock-footage-emergency-room-at-hospital-in-usa-aerial-view-of-led-light-sign-outside-of-building-at-night.webm" type="video/webm" />
                    Your browser does not support the video tag.
                </video>
            </div>
            <div className="contact-header">
                <h1>Contact Us</h1>
                <p>We are here to help you with your healthcare needs. Reach out to us anytime.</p>
            </div>
            <div className="contact-content">
                <div className="contact-info">
                    <h2>Hospital Contact Information</h2>
                    <p><strong>Address:</strong> 1234 Health St, Wellness City, TX 12345</p>
                    <p><strong>Phone:</strong> (123) 456-7890</p>
                    <p><strong>Email:</strong> info@hospitalcare.com</p>
                    <h3>Operating Hours</h3>
                    <p>Monday - Friday: 8:00 AM - 6:00 PM</p>
                    <p>Saturday: 9:00 AM - 1:00 PM</p>
                    <p>Sunday: Closed</p>
                </div>
                <div className="contact-form-section">
                    <h2>Send Us a Message</h2>
                    <form className="contact-form" onSubmit={handleSubmit}>
                        <div className="form-group">
                            <label htmlFor="name">Name</label>
                            <input
                                type="text"
                                id="name"
                                name="name"
                                value={formData.name}
                                onChange={handleChange}
                                required
                            />
                        </div>
                        <div className="form-group">
                            <label htmlFor="email">Email</label>
                            <input
                                type="email"
                                id="email"
                                name="email"
                                value={formData.email}
                                onChange={handleChange}
                                required
                            />
                        </div>
                        <div className="form-group">
                            <label htmlFor="message">Message</label>
                            <textarea
                                id="message"
                                name="message"
                                value={formData.message}
                                onChange={handleChange}
                                rows="5"
                                required
                            />
                        </div>
                        <button type="submit" className="submit-button">Send Message</button>
                    </form>
                </div>
            </div>
        </div>
    );
};

export default Contact;
