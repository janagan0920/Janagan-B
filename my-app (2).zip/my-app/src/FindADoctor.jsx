import React, { useState, useEffect } from 'react';
import './FindADoctor.css';

const DoctorList = () => {
  const [doctors, setDoctors] = useState([]);

  useEffect(() => {
    // Sample doctor data
    const doctorData = [
      {
        id: 1,
        name: "Dr. John Smith",
        designation: "Senior Cardiologist",
        specialty: "Cardiology",
        rating: 4.8,
        image: "https://via.placeholder.com/150",
        details: "Expert in heart diseases and treatment."
      },
      {
        id: 2,
        name: "Dr. Jane Doe",
        designation: "Consultant Neurologist",
        specialty: "Neurology",
        rating: 4.7,
        image: "https://via.placeholder.com/150",
        details: "Specializes in brain and nervous system disorders."
      },
      {
        id: 3,
        name: "Dr. Emily Johnson",
        designation: "Pediatrician",
        specialty: "Pediatrics",
        rating: 4.9,
        image: "https://via.placeholder.com/150",
        details: "Cares for children from birth to adolescence."
      },
      {
        id: 4,
        name: "Dr. Michael Brown",
        designation: "Orthopedic Surgeon",
        specialty: "Orthopedics",
        rating: 4.6,
        image: "https://via.placeholder.com/150",
        details: "Expert in bone and joint surgeries."
      },
      {
        id: 5,
        name: "Dr. Sarah Davis",
        designation: "Dermatologist",
        specialty: "Dermatology",
        rating: 4.5,
        image: "https://via.placeholder.com/150",
        details: "Specializes in skin conditions and treatments."
      },
    ];

    setDoctors(doctorData);
  }, []);

  return (
    <div className="doctor-list-page">
      <h1>Doctors Available</h1>
      <div className="doctor-list">
        {doctors.map((doctor) => (
          <div key={doctor.id} className="doctor-card">
            <img src={doctor.image} alt={doctor.name} className="doctor-image" />
            <h3>{doctor.name}</h3>
            <p>{doctor.designation}</p>
            <p>Specialty: {doctor.specialty}</p>
            <p>Rating: {doctor.rating} ⭐</p>
            <p className="doctor-details">{doctor.details}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default DoctorList;
