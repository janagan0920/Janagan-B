import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Login from './Login';
import HomePage from './HomePage';
import SignIn from './SignIn';
import FindADoctor from './FindADoctor';
import Contact from './Contact';
import Billing from './Billing';
import Departments from './Departments';
import BookingAppointment from './BookingAppointment'; // Import the BookingAppointment component

function App() {
    return (
        <Router>
            <Routes>
                <Route path="/" element={<Login />} />
                <Route path="/homepage" element={<HomePage />} />
                <Route path="/signup" element={<SignIn />} />
                <Route path="/findadoctor" element={<FindADoctor />} />
                <Route path="/contact" element={<Contact />} />
                <Route path="/billing" element={<Billing />} />
                <Route path="/departments" element={<Departments />} />
                <Route path="/bookappointment" element={<BookingAppointment />} /> {/* Add this route */}
            </Routes>
        </Router>
    );
}

export default App;
