import React, { useState } from "react";
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import './SignIn.css'; // Updated to match the component name

const SignIn = () => {
  const [mobileNo, setMobileNo] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const navigate = useNavigate();

  const handleRegister = async (e) => {
    e.preventDefault();

    // Check if passwords match
    if (password !== confirmPassword) {
      alert("Passwords do not match!");
      return;
    }

    const newUser = { mobileNo, email, password };

    try {
      // Fetch existing users to check if the email already exists
      const response = await axios.get('http://localhost:3001/user');
      const users = response.data;

      const emailExists = users.some(user => user.email === email);
      if (emailExists) {
        alert("Email already exists!");
        return;
      }

      // If email is unique, post the new user
      await axios.post('http://localhost:3001/user', newUser);
      alert("Registration successful!");
      navigate('/'); // Navigate to the login page (root path for Login)
    } catch (error) {
      console.error("Error during registration: ", error.response ? error.response.data : error.message);
      alert("Error during registration. Please try again.");
    }
  };

  return (
    <div className="sign-up-page">
      {/* Video Background */}
      <video className="video-background" autoPlay muted loop>
        <source src="https://www.shutterstock.com/shutterstock/videos/1094139473/preview/stock-footage-future-hospitals-and-medical-technology.webm" type="video/webm" />
        Your browser does not support the video tag.
      </video>

      {/* Sign-in Form */}
      <div className="sign-up-container">
        <form className="sign-up-form" onSubmit={handleRegister}>
          <h2 className="form-title">Sign Up</h2>

          <div className="form-group">
            <label htmlFor="mobileNo">Mobile No<span className="required">*</span>:</label>
            <div className="mobile-input-container">
              <select className="country-code">
                <option value="+91">+91 IND</option>
              </select>
              <input
                type="text"
                id="mobileNo"
                value={mobileNo}
                onChange={(e) => setMobileNo(e.target.value)}
                placeholder="Enter mobile number"
                required
              />
            </div>
          </div>

          <div className="form-group">
            <label htmlFor="email">Email Id (optional):</label>
            <input
              type="email"
              id="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="(optional)"
            />
          </div>

          <div className="form-group">
            <label htmlFor="password">Password<span className="required">*</span>:</label>
            <input
              type="password"
              id="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="xxxxxx"
              required
            />
          </div>

          <div className="form-group">
            <label htmlFor="confirmPassword">Confirm Password<span className="required">*</span>:</label>
            <input
              type="password"
              id="confirmPassword"
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              placeholder="xxxxxx"
              required
            />
          </div>

          <p className="login-text">
            Already a member? <a href="/">Click here</a> to login.
          </p>

          <button type="submit" className="register-btn">Register</button>
        </form>
      </div>
    </div>
  );
};

export default SignIn;
